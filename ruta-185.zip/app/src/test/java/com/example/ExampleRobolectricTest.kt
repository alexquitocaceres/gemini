package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.ExerciseSessionSummaryEntity
import com.example.data.model.ExercisePhase
import com.example.data.model.RoutineCatalog
import com.example.data.repository.FitnessRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase
    private lateinit var repository: FitnessRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = FitnessRepository(db.appDao())
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Ruta 185", appName)
    }

    @Test
    fun `routine maintains 5 days with weights before cardio`() {
        assertEquals(5, RoutineCatalog.weeklyPlan.size)
        RoutineCatalog.weeklyPlan.forEach { day ->
            assertEquals(ExercisePhase.WEIGHTS, day.exercises.first().phase)
            assertEquals(ExercisePhase.CARDIO, day.exercises.last().phase)
            val cardioStart = day.exercises.indexOfFirst { it.phase == ExercisePhase.CARDIO }
            val lastWeight = day.exercises.indexOfLast { it.phase == ExercisePhase.WEIGHTS }
            assertTrue("Weights must precede cardio on ${day.dayName}", lastWeight < cardioStart)
        }
    }

    @Test
    fun `initial room seed sets 220 lb start and 185 lb goal`() = runTest {
        repository.ensureInitialized()
        val goal = repository.userGoal.first()!!
        val logs = repository.weightLogs.first()

        assertEquals(220f, goal.startWeightLb, 0.01f)
        assertEquals(220f, goal.currentWeightLb, 0.01f)
        assertEquals(185f, goal.targetWeightLb, 0.01f)
        assertEquals(1, logs.size)

        repository.logWeeklyWeight(217.5f, 40.5f, "Semana 2 en ayunas")
        val updatedGoal = repository.userGoal.first()!!
        val updatedLogs = repository.weightLogs.first()
        assertEquals(217.5f, updatedGoal.currentWeightLb, 0.01f)
        assertEquals(2, updatedLogs.size)
    }

    @Test
    fun `progression rule triggers only after two consecutive easy weeks`() {
        val currentWeek = "2026-W48"
        val oneEasyWeek = listOf(
            ExerciseSessionSummaryEntity(
                weekKey = "2026-W47",
                dayOfWeek = 1,
                exerciseId = "mon_squat_press",
                variantUsed = "Prensa de piernas",
                allSetsCompleted = true,
                effortRating = 1,
                avgWeightLb = 90f,
                completedAtMillis = 1000L
            )
        )
        assertFalse(FitnessRepository.shouldSuggestWeightIncrease(oneEasyWeek, currentWeek))

        val twoEasyWeeks = oneEasyWeek + ExerciseSessionSummaryEntity(
            weekKey = "2026-W46",
            dayOfWeek = 1,
            exerciseId = "mon_squat_press",
            variantUsed = "Prensa de piernas",
            allSetsCompleted = true,
            effortRating = 1,
            avgWeightLb = 90f,
            completedAtMillis = 500L
        )
        assertTrue(FitnessRepository.shouldSuggestWeightIncrease(twoEasyWeeks, currentWeek))

        val easyThenHard = listOf(
            oneEasyWeek.first(),
            ExerciseSessionSummaryEntity(
                weekKey = "2026-W46",
                dayOfWeek = 1,
                exerciseId = "mon_squat_press",
                variantUsed = "Prensa de piernas",
                allSetsCompleted = true,
                effortRating = 2,
                avgWeightLb = 90f,
                completedAtMillis = 500L
            )
        )
        assertFalse(FitnessRepository.shouldSuggestWeightIncrease(easyThenHard, currentWeek))
    }
}
