package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    @Query("SELECT * FROM user_goal WHERE id = 1")
    fun observeUserGoal(): Flow<UserGoalEntity?>

    @Query("SELECT * FROM user_goal WHERE id = 1")
    suspend fun getUserGoalOnce(): UserGoalEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertUserGoal(goal: UserGoalEntity)

    @Query("SELECT * FROM weight_logs ORDER BY recordedAtMillis ASC")
    fun observeWeightLogs(): Flow<List<WeightLogEntity>>

    @Query("SELECT COUNT(*) FROM weight_logs")
    suspend fun getWeightLogCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeightLog(log: WeightLogEntity)

    @Query("DELETE FROM weight_logs WHERE id = :id")
    suspend fun deleteWeightLogById(id: Long)

    @Query("SELECT * FROM exercise_preferences")
    fun observeExercisePreferences(): Flow<List<ExercisePreferenceEntity>>

    @Query("SELECT * FROM exercise_preferences WHERE exerciseId = :exerciseId")
    suspend fun getExercisePreferenceOnce(exerciseId: String): ExercisePreferenceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertExercisePreference(pref: ExercisePreferenceEntity)

    @Query("SELECT * FROM exercise_set_logs WHERE weekKey = :weekKey AND dayOfWeek = :dayOfWeek ORDER BY setNumber ASC")
    fun observeSetLogsForDay(weekKey: String, dayOfWeek: Int): Flow<List<ExerciseSetLogEntity>>

    @Query("SELECT * FROM exercise_set_logs WHERE weekKey = :weekKey")
    fun observeSetLogsForWeek(weekKey: String): Flow<List<ExerciseSetLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetLog(log: ExerciseSetLogEntity)

    @Query("DELETE FROM exercise_set_logs WHERE weekKey = :weekKey AND exerciseId = :exerciseId AND setNumber = :setNumber")
    suspend fun deleteSetLog(weekKey: String, exerciseId: String, setNumber: Int)

    @Query("SELECT * FROM exercise_session_summaries ORDER BY completedAtMillis DESC")
    fun observeAllSessionSummaries(): Flow<List<ExerciseSessionSummaryEntity>>

    @Query("SELECT * FROM exercise_session_summaries WHERE weekKey = :weekKey AND dayOfWeek = :dayOfWeek")
    fun observeSummariesForDay(weekKey: String, dayOfWeek: Int): Flow<List<ExerciseSessionSummaryEntity>>

    @Query("DELETE FROM exercise_session_summaries WHERE weekKey = :weekKey AND exerciseId = :exerciseId")
    suspend fun deleteSummaryForExerciseWeek(weekKey: String, exerciseId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSessionSummary(summary: ExerciseSessionSummaryEntity)

    @Query("SELECT * FROM meal_checks WHERE dateIso = :dateIso")
    fun observeMealChecksForDate(dateIso: String): Flow<List<MealCheckEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMealCheck(mealCheck: MealCheckEntity)

    @Query("SELECT * FROM daily_water WHERE dateIso = :dateIso")
    fun observeDailyWater(dateIso: String): Flow<DailyWaterEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDailyWater(water: DailyWaterEntity)
}
