package com.example.data.model

enum class ExercisePhase {
    WEIGHTS,
    CARDIO
}

enum class ExerciseTrackingMode {
    SETS_REPS,
    TIMED_SETS,
    CARDIO_DURATION
}

enum class PostureDiagramType {
    LEG_PRESS,
    ROMANIAN_DEADLIFT,
    LEG_EXTENSION,
    LEG_CURL,
    CALF_RAISE,
    CHEST_PRESS,
    SHOULDER_PRESS,
    LATERAL_RAISE,
    TRICEPS_PUSHDOWN,
    LAT_PULLDOWN,
    SEATED_ROW,
    FACE_PULL,
    BICEP_CURL,
    LUNGES,
    PLANK,
    CARDIO_TREADMILL,
    CARDIO_BIKE
}

data class ExerciseDefinition(
    val id: String,
    val dayOfWeek: Int,
    val orderIndex: Int,
    val phase: ExercisePhase,
    val trackingMode: ExerciseTrackingMode,
    val primaryName: String,
    val variants: List<String>,
    val sets: Int,
    val targetRepsMin: Int,
    val targetRepsMax: Int,
    val targetDurationMinSeconds: Int = 0,
    val targetDurationMaxSeconds: Int = 0,
    val restSeconds: Int,
    val beginnerStartWeightLb: Float,
    val targetDisplay: String,
    val targetMuscles: String,
    val beginnerTip: String,
    val executionSteps: List<String>,
    val commonMistake: String,
    val videoSearchQuery: String,
    val diagramType: PostureDiagramType
)

data class WorkoutDayPlan(
    val dayOfWeek: Int,
    val dayName: String,
    val shortName: String,
    val focusTitle: String,
    val beginnerNote: String,
    val estimatedMinutes: Int,
    val exercises: List<ExerciseDefinition>
)

enum class MealSlot(val label: String, val timeHint: String) {
    DESAYUNO("Desayuno", "7:00 – 9:30 AM"),
    ALMUERZO("Almuerzo", "12:30 – 2:30 PM"),
    MERIENDA("Merienda / Pre-entreno", "4:30 – 6:00 PM"),
    CENA("Cena", "7:30 – 9:30 PM")
}

data class MealOption(
    val id: String,
    val slot: MealSlot,
    val title: String,
    val portions: String,
    val calories: Int,
    val proteinG: Int,
    val carbsG: Int,
    val fatsG: Int,
    val satietyTip: String
)
