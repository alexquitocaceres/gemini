package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_goal")
data class UserGoalEntity(
    @PrimaryKey val id: Int = 1,
    val startWeightLb: Float = 220f,
    val currentWeightLb: Float = 220f,
    val targetWeightLb: Float = 185f,
    val dailyCalorieTarget: Int = 2050,
    val dailyProteinTargetG: Int = 165
)

@Entity(tableName = "weight_logs")
data class WeightLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val weekNumber: Int,
    val weightLb: Float,
    val waistIn: Float? = null,
    val note: String = "",
    val recordedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "exercise_preferences")
data class ExercisePreferenceEntity(
    @PrimaryKey val exerciseId: String,
    val selectedVariant: String,
    val lastWeightLb: Float,
    val machineSettingNote: String = "",
    val customVideoUrl: String = ""
)

@Entity(tableName = "exercise_set_logs")
data class ExerciseSetLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val weekKey: String,
    val dayOfWeek: Int,
    val exerciseId: String,
    val variantUsed: String,
    val setNumber: Int,
    val weightLb: Float,
    val repsCompleted: Int,
    val durationSeconds: Int,
    val completedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "exercise_session_summaries")
data class ExerciseSessionSummaryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val weekKey: String,
    val dayOfWeek: Int,
    val exerciseId: String,
    val variantUsed: String,
    val allSetsCompleted: Boolean,
    /** 1 = Fácil (3+ RIR), 2 = Ideal (1-2 RIR), 3 = Al límite (0 RIR) */
    val effortRating: Int,
    val avgWeightLb: Float,
    val completedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "meal_checks")
data class MealCheckEntity(
    @PrimaryKey val id: String,
    val dateIso: String,
    val slotName: String,
    val optionId: String,
    val optionTitle: String,
    val calories: Int,
    val proteinG: Int,
    val completed: Boolean
)

@Entity(tableName = "daily_water")
data class DailyWaterEntity(
    @PrimaryKey val dateIso: String,
    val glasses: Int = 0
)
