package com.example.data.model

object NutritionCatalog {

    const val DEFAULT_CALORIE_TARGET = 2050
    const val DEFAULT_PROTEIN_TARGET_G = 165
    const val TARGET_WATER_GLASSES = 10

    val beginnerRules: List<String> = listOf(
        "Déficit sostenible: ~2,050 kcal diarias te permiten perder ~1 a 1.5 lb por semana sin perder energía para entrenar.",
        "Proteína primero: apunta a ~165 g diarios (pollo, huevo, atún, carne magra, yogur griego) para proteger el músculo.",
        "Plato 50% verduras: llena la mitad del plato en almuerzo y cena con ensalada o vegetales cocidos para sentir saciedad.",
        "Cero calorías líquidas: sustituye refrescos y jugos por agua natural, agua mineral, té o café sin azúcar."
    )

    val mealOptions: List<MealOption> = listOf(
        // DESAYUNO (~450 kcal)
        MealOption(
            id = "bk_eggs_toast",
            slot = MealSlot.DESAYUNO,
            title = "Huevos revueltos con espinaca y pan integral",
            portions = "3 huevos enteros + 1 clara, 1 taza de espinaca, 2 rebanadas de pan integral, café negro o té",
            calories = 450,
            proteinG = 34,
            carbsG = 32,
            fatsG = 20,
            satietyTip = "La proteína y la fibra del pan integral mantienen el hambre controlada hasta mediodía."
        ),
        MealOption(
            id = "bk_oats_yogurt",
            slot = MealSlot.DESAYUNO,
            title = "Avena proteica con yogur griego y fruta",
            portions = "1/2 taza de avena cocida en agua, 180 g de yogur griego natural sin azúcar, 1/2 taza de fresas o manzana, canela",
            calories = 430,
            proteinG = 30,
            carbsG = 54,
            fatsG = 8,
            satietyTip = "Excelente opción rápida si entrenas temprano."
        ),
        MealOption(
            id = "bk_omelet_turkey",
            slot = MealSlot.DESAYUNO,
            title = "Omelette de pavo, vegetales y aguacate",
            portions = "2 huevos + 3 claras, 60 g de pechuga de pavo, tomate y pimiento, 1/4 de aguacate y 1 tortilla de maíz",
            calories = 440,
            proteinG = 38,
            carbsG = 22,
            fatsG = 21,
            satietyTip = "Bajo en carbohidratos simples y alto en saciedad."
        ),

        // ALMUERZO (~650 kcal)
        MealOption(
            id = "lu_chicken_rice",
            slot = MealSlot.ALMUERZO,
            title = "Pechuga a la plancha, arroz y ensalada grande",
            portions = "180 g de pechuga de pollo (peso cocido), 1 taza de arroz cocido, 2 tazas de ensalada verde con limón y 1 cdta de aceite de oliva",
            calories = 640,
            proteinG = 56,
            carbsG = 58,
            fatsG = 16,
            satietyTip = "Comida clásica equilibrada para rendir bien en pesas y cardio."
        ),
        MealOption(
            id = "lu_beef_potato",
            slot = MealSlot.ALMUERZO,
            title = "Carne magra de res, papa cocida y brócoli",
            portions = "180 g de res magra a la plancha, 1 papa mediana cocida (200 g), 1.5 tazas de brócoli y zanahoria al vapor",
            calories = 650,
            proteinG = 52,
            carbsG = 52,
            fatsG = 22,
            satietyTip = "La papa cocida es uno de los alimentos con mayor índice de saciedad."
        ),
        MealOption(
            id = "lu_fish_quinoa",
            slot = MealSlot.ALMUERZO,
            title = "Filete de pescado o tilapia con arroz/quinoa",
            portions = "220 g de filete de pescado al horno o plancha, 1 taza de quinoa o arroz cocido, vegetales salteados con 1 cdta de aceite",
            calories = 600,
            proteinG = 54,
            carbsG = 48,
            fatsG = 16,
            satietyTip = "Ligero en digestión y muy alto en proteína magra."
        ),

        // MERIENDA / PRE-ENTRENO (~350 kcal)
        MealOption(
            id = "sn_yogurt_fruit",
            slot = MealSlot.MERIENDA,
            title = "Yogur griego natural con manzana y almendras",
            portions = "200 g de yogur griego sin azúcar, 1 manzana mediana picada y 10 almendras naturales",
            calories = 340,
            proteinG = 24,
            carbsG = 32,
            fatsG = 11,
            satietyTip = "Ideal 60–90 minutos antes de ir al gimnasio."
        ),
        MealOption(
            id = "sn_tuna_toast",
            slot = MealSlot.MERIENDA,
            title = "Tostadas horneadas con atún en agua",
            portions = "1 lata grande de atún en agua escurrido (120 g), 2 tostadas integrales o de maíz horneadas, pico de gallo o pepino",
            calories = 330,
            proteinG = 34,
            carbsG = 30,
            fatsG = 6,
            satietyTip = "Ultra práctica y con más de 30 g de proteína."
        ),
        MealOption(
            id = "sn_shake_banana",
            slot = MealSlot.MERIENDA,
            title = "Batido de proteína con plátano pequeño",
            portions = "1 medida (scoop) de proteína whey o vegetal en agua, 1 plátano pequeño y 1 cdta de mantequilla de maní",
            calories = 345,
            proteinG = 28,
            carbsG = 38,
            fatsG = 8,
            satietyTip = "Rápida de digerir antes o justo después de entrenar."
        ),

        // CENA (~560 kcal)
        MealOption(
            id = "dn_chicken_salad",
            slot = MealSlot.CENA,
            title = "Ensalada completa con pollo y aguacate",
            portions = "170 g de pechuga desmenuzada o a la plancha, lechuga, pepino, tomate, cebolla, 1/3 de aguacate y limón",
            calories = 520,
            proteinG = 48,
            carbsG = 18,
            fatsG = 26,
            satietyTip = "Cena fresca de gran volumen y muy baja en calorías densas."
        ),
        MealOption(
            id = "dn_egg_veggies",
            slot = MealSlot.CENA,
            title = "Revuelto nocturno de claras, huevo y vegetales",
            portions = "4 claras + 2 huevos enteros, 1 taza de calabacín/champiñones salteados, 40 g de queso fresco bajo en grasa y 1 tortilla",
            calories = 510,
            proteinG = 42,
            carbsG = 24,
            fatsG = 24,
            satietyTip = "Fácil de preparar en 10 minutos al volver del gimnasio."
        ),
        MealOption(
            id = "dn_stir_fry",
            slot = MealSlot.CENA,
            title = "Salteado de pollo o carne magra con verduras",
            portions = "180 g de pollo en tiras, 2 tazas de pimientos, brócoli y calabacín salteados con salsa de soya baja en sodio y 1/2 taza de arroz",
            calories = 570,
            proteinG = 50,
            carbsG = 44,
            fatsG = 16,
            satietyTip = "Satisface antojos nocturnos con buen volumen y proteína."
        )
    )

    fun optionsForSlot(slot: MealSlot): List<MealOption> = mealOptions.filter { it.slot == slot }
}
