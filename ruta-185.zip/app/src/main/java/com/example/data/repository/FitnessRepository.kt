package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.local.DailyWaterEntity
import com.example.data.local.ExercisePreferenceEntity
import com.example.data.local.ExerciseSessionSummaryEntity
import com.example.data.local.ExerciseSetLogEntity
import com.example.data.local.MealCheckEntity
import com.example.data.local.UserGoalEntity
import com.example.data.local.WeightLogEntity
import com.example.data.model.MealOption
import com.example.data.model.MealSlot
import com.example.data.model.NutritionCatalog
import com.example.data.model.RoutineCatalog
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class FitnessRepository(private val dao: AppDao) {

    val userGoal: Flow<UserGoalEntity?> = dao.observeUserGoal()
    val weightLogs: Flow<List<WeightLogEntity>> = dao.observeWeightLogs()
    val exercisePreferences: Flow<List<ExercisePreferenceEntity>> = dao.observeExercisePreferences()
    val allSessionSummaries: Flow<List<ExerciseSessionSummaryEntity>> = dao.observeAllSessionSummaries()

    fun observeSetLogsForWeek(weekKey: String): Flow<List<ExerciseSetLogEntity>> =
        dao.observeSetLogsForWeek(weekKey)

    fun observeSetLogsForDay(weekKey: String, dayOfWeek: Int): Flow<List<ExerciseSetLogEntity>> =
        dao.observeSetLogsForDay(weekKey, dayOfWeek)

    fun observeSummariesForDay(weekKey: String, dayOfWeek: Int): Flow<List<ExerciseSessionSummaryEntity>> =
        dao.observeSummariesForDay(weekKey, dayOfWeek)

    fun observeMealChecks(dateIso: String): Flow<List<MealCheckEntity>> =
        dao.observeMealChecksForDate(dateIso)

    fun observeDailyWater(dateIso: String): Flow<DailyWaterEntity?> =
        dao.observeDailyWater(dateIso)

    suspend fun ensureInitialized() {
        if (dao.getUserGoalOnce() == null) {
            dao.upsertUserGoal(
                UserGoalEntity(
                    id = 1,
                    startWeightLb = 220f,
                    currentWeightLb = 220f,
                    targetWeightLb = 185f,
                    dailyCalorieTarget = NutritionCatalog.DEFAULT_CALORIE_TARGET,
                    dailyProteinTargetG = NutritionCatalog.DEFAULT_PROTEIN_TARGET_G
                )
            )
        }
        if (dao.getWeightLogCount() == 0) {
            dao.insertWeightLog(
                WeightLogEntity(
                    weekNumber = 1,
                    weightLb = 220f,
                    waistIn = null,
                    note = "Peso inicial · Inicio de Ruta 185",
                    recordedAtMillis = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun logWeeklyWeight(weightLb: Float, waistIn: Float?, note: String) {
        val currentCount = dao.getWeightLogCount()
        val nextWeek = currentCount + 1
        dao.insertWeightLog(
            WeightLogEntity(
                weekNumber = nextWeek,
                weightLb = weightLb,
                waistIn = waistIn,
                note = note.ifBlank { "Medición semana $nextWeek" },
                recordedAtMillis = System.currentTimeMillis()
            )
        )
        val goal = dao.getUserGoalOnce() ?: UserGoalEntity()
        dao.upsertUserGoal(goal.copy(currentWeightLb = weightLb))
    }

    suspend fun deleteWeightLog(log: WeightLogEntity, remainingLogs: List<WeightLogEntity>) {
        dao.deleteWeightLogById(log.id)
        val latest = remainingLogs.filter { it.id != log.id }.maxByOrNull { it.recordedAtMillis }
        if (latest != null) {
            val goal = dao.getUserGoalOnce() ?: UserGoalEntity()
            dao.upsertUserGoal(goal.copy(currentWeightLb = latest.weightLb))
        }
    }

    suspend fun updateCalorieAndGoalTargets(
        targetWeightLb: Float,
        dailyCalories: Int,
        dailyProteinG: Int
    ) {
        val goal = dao.getUserGoalOnce() ?: UserGoalEntity()
        dao.upsertUserGoal(
            goal.copy(
                targetWeightLb = targetWeightLb,
                dailyCalorieTarget = dailyCalories,
                dailyProteinTargetG = dailyProteinG
            )
        )
    }

    suspend fun savePreferredVariant(exerciseId: String, variant: String) {
        val def = RoutineCatalog.getExercise(exerciseId)
        val existing = dao.getExercisePreferenceOnce(exerciseId)
        dao.upsertExercisePreference(
            ExercisePreferenceEntity(
                exerciseId = exerciseId,
                selectedVariant = variant,
                lastWeightLb = existing?.lastWeightLb ?: (def?.beginnerStartWeightLb ?: 0f),
                machineSettingNote = existing?.machineSettingNote ?: "",
                customVideoUrl = existing?.customVideoUrl ?: ""
            )
        )
    }

    suspend fun saveMachineNote(exerciseId: String, note: String) {
        val def = RoutineCatalog.getExercise(exerciseId)
        val existing = dao.getExercisePreferenceOnce(exerciseId)
        dao.upsertExercisePreference(
            ExercisePreferenceEntity(
                exerciseId = exerciseId,
                selectedVariant = existing?.selectedVariant ?: (def?.variants?.firstOrNull() ?: ""),
                lastWeightLb = existing?.lastWeightLb ?: (def?.beginnerStartWeightLb ?: 0f),
                machineSettingNote = note,
                customVideoUrl = existing?.customVideoUrl ?: ""
            )
        )
    }

    suspend fun saveCustomVideoUrl(exerciseId: String, url: String) {
        val def = RoutineCatalog.getExercise(exerciseId)
        val existing = dao.getExercisePreferenceOnce(exerciseId)
        dao.upsertExercisePreference(
            ExercisePreferenceEntity(
                exerciseId = exerciseId,
                selectedVariant = existing?.selectedVariant ?: (def?.variants?.firstOrNull() ?: ""),
                lastWeightLb = existing?.lastWeightLb ?: (def?.beginnerStartWeightLb ?: 0f),
                machineSettingNote = existing?.machineSettingNote ?: "",
                customVideoUrl = url.trim()
            )
        )
    }

    suspend fun logSetCompleted(
        weekKey: String,
        dayOfWeek: Int,
        exerciseId: String,
        variantUsed: String,
        setNumber: Int,
        weightLb: Float,
        repsCompleted: Int,
        durationSeconds: Int
    ) {
        dao.deleteSetLog(weekKey, exerciseId, setNumber)
        dao.insertSetLog(
            ExerciseSetLogEntity(
                weekKey = weekKey,
                dayOfWeek = dayOfWeek,
                exerciseId = exerciseId,
                variantUsed = variantUsed,
                setNumber = setNumber,
                weightLb = weightLb,
                repsCompleted = repsCompleted,
                durationSeconds = durationSeconds
            )
        )
        if (weightLb > 0f) {
            val existing = dao.getExercisePreferenceOnce(exerciseId)
            dao.upsertExercisePreference(
                ExercisePreferenceEntity(
                    exerciseId = exerciseId,
                    selectedVariant = variantUsed,
                    lastWeightLb = weightLb,
                    machineSettingNote = existing?.machineSettingNote ?: "",
                    customVideoUrl = existing?.customVideoUrl ?: ""
                )
            )
        }
    }

    suspend fun removeSetLog(weekKey: String, exerciseId: String, setNumber: Int) {
        dao.deleteSetLog(weekKey, exerciseId, setNumber)
    }

    suspend fun saveExerciseEffortSummary(
        weekKey: String,
        dayOfWeek: Int,
        exerciseId: String,
        variantUsed: String,
        allSetsCompleted: Boolean,
        effortRating: Int,
        avgWeightLb: Float
    ) {
        dao.deleteSummaryForExerciseWeek(weekKey, exerciseId)
        dao.insertSessionSummary(
            ExerciseSessionSummaryEntity(
                weekKey = weekKey,
                dayOfWeek = dayOfWeek,
                exerciseId = exerciseId,
                variantUsed = variantUsed,
                allSetsCompleted = allSetsCompleted,
                effortRating = effortRating,
                avgWeightLb = avgWeightLb
            )
        )
    }

    suspend fun toggleMealOption(
        dateIso: String,
        slot: MealSlot,
        option: MealOption,
        completed: Boolean
    ) {
        dao.upsertMealCheck(
            MealCheckEntity(
                id = "${dateIso}_${slot.name}",
                dateIso = dateIso,
                slotName = slot.name,
                optionId = option.id,
                optionTitle = option.title,
                calories = option.calories,
                proteinG = option.proteinG,
                completed = completed
            )
        )
    }

    suspend fun setWaterGlasses(dateIso: String, glasses: Int) {
        dao.upsertDailyWater(
            DailyWaterEntity(
                dateIso = dateIso,
                glasses = glasses.coerceIn(0, 16)
            )
        )
    }

    companion object {
        fun currentWeekKey(timeMillis: Long = System.currentTimeMillis()): String {
            val cal = Calendar.getInstance().apply {
                timeInMillis = timeMillis
                firstDayOfWeek = Calendar.MONDAY
                minimalDaysInFirstWeek = 4
            }
            val year = cal.get(Calendar.YEAR)
            val week = cal.get(Calendar.WEEK_OF_YEAR)
            return String.format(Locale.US, "%d-W%02d", year, week)
        }

        fun todayIso(timeMillis: Long = System.currentTimeMillis()): String {
            return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(timeMillis))
        }

        fun defaultDayOfWeek(timeMillis: Long = System.currentTimeMillis()): Int {
            val cal = Calendar.getInstance().apply { timeInMillis = timeMillis }
            return when (cal.get(Calendar.DAY_OF_WEEK)) {
                Calendar.MONDAY -> 1
                Calendar.TUESDAY -> 2
                Calendar.WEDNESDAY -> 3
                Calendar.THURSDAY -> 4
                Calendar.FRIDAY -> 5
                else -> 1
            }
        }

        /**
         * Implements the user's exact progression rule:
         * "Si completas todas las series fácil dos semanas seguidas, sube un poco el peso."
         */
        fun shouldSuggestWeightIncrease(
            summariesForExercise: List<ExerciseSessionSummaryEntity>,
            currentWeekKey: String
        ): Boolean {
            val previousCompletedWeeks = summariesForExercise
                .filter { it.weekKey != currentWeekKey }
                .sortedByDescending { it.completedAtMillis }
                .distinctBy { it.weekKey }
                .take(2)

            if (previousCompletedWeeks.size < 2) return false
            return previousCompletedWeeks.all { it.allSetsCompleted && it.effortRating == 1 }
        }
    }
}
