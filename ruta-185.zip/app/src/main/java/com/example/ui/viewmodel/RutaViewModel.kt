package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ExercisePreferenceEntity
import com.example.data.local.ExerciseSessionSummaryEntity
import com.example.data.local.ExerciseSetLogEntity
import com.example.data.local.MealCheckEntity
import com.example.data.local.UserGoalEntity
import com.example.data.local.WeightLogEntity
import com.example.data.model.ExercisePhase
import com.example.data.model.MealOption
import com.example.data.model.MealSlot
import com.example.data.model.RoutineCatalog
import com.example.data.repository.FitnessRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class RestTimerState(
    val isActive: Boolean = false,
    val isPaused: Boolean = false,
    val remainingSeconds: Int = 0,
    val totalSeconds: Int = 0,
    val exerciseName: String = "",
    val completionSignal: Int = 0
)

enum class ExerciseTimerPhase {
    IDLE,
    PREP,
    WORK
}

data class ActiveExerciseTimerState(
    val exerciseId: String = "",
    val setNumber: Int = 1,
    val phase: ExerciseTimerPhase = ExerciseTimerPhase.IDLE,
    val isRunning: Boolean = false,
    val remainingSeconds: Int = 0,
    val totalSeconds: Int = 0,
    val targetWorkSeconds: Int = 0,
    val completionSignal: Int = 0
)

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class RutaViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: FitnessRepository = FitnessRepository(
        AppDatabase.getInstance(application).appDao()
    )

    val currentWeekKey: String = FitnessRepository.currentWeekKey()
    val todayIso: String = FitnessRepository.todayIso()

    private val _selectedDayOfWeek = MutableStateFlow(FitnessRepository.defaultDayOfWeek())
    val selectedDayOfWeek: StateFlow<Int> = _selectedDayOfWeek.asStateFlow()

    private val _restTimer = MutableStateFlow(RestTimerState())
    val restTimer: StateFlow<RestTimerState> = _restTimer.asStateFlow()

    private val _exerciseTimer = MutableStateFlow(ActiveExerciseTimerState())
    val exerciseTimer: StateFlow<ActiveExerciseTimerState> = _exerciseTimer.asStateFlow()

    private var restTimerJob: Job? = null
    private var exerciseTimerJob: Job? = null

    val userGoal: StateFlow<UserGoalEntity> = repository.userGoal
        .combine(MutableStateFlow(Unit)) { goal, _ -> goal ?: UserGoalEntity() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserGoalEntity())

    val weightLogs: StateFlow<List<WeightLogEntity>> = repository.weightLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val exercisePreferences: StateFlow<Map<String, ExercisePreferenceEntity>> =
        repository.exercisePreferences
            .combine(MutableStateFlow(Unit)) { list, _ -> list.associateBy { it.exerciseId } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val weekSetLogs: StateFlow<List<ExerciseSetLogEntity>> =
        repository.observeSetLogsForWeek(currentWeekKey)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeDaySetLogs: StateFlow<List<ExerciseSetLogEntity>> =
        _selectedDayOfWeek.flatMapLatest { day ->
            repository.observeSetLogsForDay(currentWeekKey, day)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeDaySummaries: StateFlow<List<ExerciseSessionSummaryEntity>> =
        _selectedDayOfWeek.flatMapLatest { day ->
            repository.observeSummariesForDay(currentWeekKey, day)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val progressionAlerts: StateFlow<Map<String, Boolean>> =
        repository.allSessionSummaries
            .combine(MutableStateFlow(currentWeekKey)) { summaries, weekKey ->
                summaries.groupBy { it.exerciseId }.mapValues { (_, list) ->
                    FitnessRepository.shouldSuggestWeightIncrease(list, weekKey)
                }
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val mealChecksToday: StateFlow<Map<String, MealCheckEntity>> =
        repository.observeMealChecks(todayIso)
            .combine(MutableStateFlow(Unit)) { list, _ -> list.associateBy { it.slotName } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val waterGlassesToday: StateFlow<Int> =
        repository.observeDailyWater(todayIso)
            .combine(MutableStateFlow(Unit)) { entity, _ -> entity?.glasses ?: 0 }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    init {
        viewModelScope.launch {
            repository.ensureInitialized()
        }
    }

    fun selectDay(dayOfWeek: Int) {
        _selectedDayOfWeek.value = dayOfWeek.coerceIn(1, 5)
    }

    fun logWeeklyWeight(weightLb: Float, waistIn: Float?, note: String) {
        viewModelScope.launch {
            repository.logWeeklyWeight(weightLb, waistIn, note)
        }
    }

    fun deleteWeightLog(log: WeightLogEntity) {
        viewModelScope.launch {
            repository.deleteWeightLog(log, weightLogs.value)
        }
    }

    fun updateGoalTargets(targetWeightLb: Float, dailyCalories: Int, dailyProteinG: Int) {
        viewModelScope.launch {
            repository.updateCalorieAndGoalTargets(targetWeightLb, dailyCalories, dailyProteinG)
        }
    }

    fun selectVariant(exerciseId: String, variant: String) {
        viewModelScope.launch {
            repository.savePreferredVariant(exerciseId, variant)
        }
    }

    fun saveMachineNote(exerciseId: String, note: String) {
        viewModelScope.launch {
            repository.saveMachineNote(exerciseId, note)
        }
    }

    fun saveCustomVideoUrl(exerciseId: String, url: String) {
        viewModelScope.launch {
            repository.saveCustomVideoUrl(exerciseId, url)
        }
    }

    fun toggleSetLog(
        dayOfWeek: Int,
        exerciseId: String,
        variantUsed: String,
        setNumber: Int,
        weightLb: Float,
        repsCompleted: Int,
        durationSeconds: Int,
        restSeconds: Int,
        exerciseTitle: String,
        currentlyCompleted: Boolean
    ) {
        viewModelScope.launch {
            if (currentlyCompleted) {
                repository.removeSetLog(currentWeekKey, exerciseId, setNumber)
            } else {
                repository.logSetCompleted(
                    weekKey = currentWeekKey,
                    dayOfWeek = dayOfWeek,
                    exerciseId = exerciseId,
                    variantUsed = variantUsed,
                    setNumber = setNumber,
                    weightLb = weightLb,
                    repsCompleted = repsCompleted,
                    durationSeconds = durationSeconds
                )
                if (restSeconds > 0) {
                    startRestTimer(restSeconds, exerciseTitle)
                }
            }
        }
    }

    fun saveEffortRating(
        dayOfWeek: Int,
        exerciseId: String,
        variantUsed: String,
        allSetsCompleted: Boolean,
        effortRating: Int,
        avgWeightLb: Float
    ) {
        viewModelScope.launch {
            repository.saveExerciseEffortSummary(
                weekKey = currentWeekKey,
                dayOfWeek = dayOfWeek,
                exerciseId = exerciseId,
                variantUsed = variantUsed,
                allSetsCompleted = allSetsCompleted,
                effortRating = effortRating,
                avgWeightLb = avgWeightLb
            )
        }
    }

    // --- Rest Timer Controls ---

    fun startRestTimer(seconds: Int, exerciseName: String) {
        restTimerJob?.cancel()
        _restTimer.value = RestTimerState(
            isActive = true,
            isPaused = false,
            remainingSeconds = seconds,
            totalSeconds = seconds,
            exerciseName = exerciseName,
            completionSignal = _restTimer.value.completionSignal
        )
        launchRestTicker()
    }

    fun toggleRestPause() {
        val current = _restTimer.value
        if (!current.isActive) return
        val nextPaused = !current.isPaused
        _restTimer.value = current.copy(isPaused = nextPaused)
        if (nextPaused) {
            restTimerJob?.cancel()
        } else {
            launchRestTicker()
        }
    }

    fun adjustRestTimer(deltaSeconds: Int) {
        val current = _restTimer.value
        if (!current.isActive) return
        val newRemaining = (current.remainingSeconds + deltaSeconds).coerceAtLeast(1)
        val newTotal = maxOf(current.totalSeconds, newRemaining)
        _restTimer.value = current.copy(remainingSeconds = newRemaining, totalSeconds = newTotal)
    }

    fun stopRestTimer() {
        restTimerJob?.cancel()
        _restTimer.value = _restTimer.value.copy(isActive = false, remainingSeconds = 0)
    }

    private fun launchRestTicker() {
        restTimerJob?.cancel()
        restTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                val current = _restTimer.value
                if (!current.isActive || current.isPaused) break
                val next = current.remainingSeconds - 1
                if (next <= 0) {
                    _restTimer.value = current.copy(
                        isActive = false,
                        remainingSeconds = 0,
                        completionSignal = current.completionSignal + 1
                    )
                    break
                } else {
                    _restTimer.value = current.copy(remainingSeconds = next)
                }
            }
        }
    }

    // --- Active Exercise Timer (Plank & Cardio) ---

    fun startTimedExercise(
        exerciseId: String,
        setNumber: Int,
        workSeconds: Int,
        includePrepCountdown: Boolean,
        dayOfWeek: Int,
        variantUsed: String,
        restAfterSeconds: Int,
        exerciseTitle: String
    ) {
        exerciseTimerJob?.cancel()
        val initialPhase = if (includePrepCountdown) ExerciseTimerPhase.PREP else ExerciseTimerPhase.WORK
        val initialSeconds = if (includePrepCountdown) 5 else workSeconds
        _exerciseTimer.value = ActiveExerciseTimerState(
            exerciseId = exerciseId,
            setNumber = setNumber,
            phase = initialPhase,
            isRunning = true,
            remainingSeconds = initialSeconds,
            totalSeconds = initialSeconds,
            targetWorkSeconds = workSeconds,
            completionSignal = _exerciseTimer.value.completionSignal
        )
        launchExerciseTicker(
            dayOfWeek = dayOfWeek,
            variantUsed = variantUsed,
            restAfterSeconds = restAfterSeconds,
            exerciseTitle = exerciseTitle
        )
    }

    fun toggleExerciseTimerPause(
        dayOfWeek: Int,
        variantUsed: String,
        restAfterSeconds: Int,
        exerciseTitle: String
    ) {
        val current = _exerciseTimer.value
        if (current.phase == ExerciseTimerPhase.IDLE) return
        val nextRunning = !current.isRunning
        _exerciseTimer.value = current.copy(isRunning = nextRunning)
        if (!nextRunning) {
            exerciseTimerJob?.cancel()
        } else {
            launchExerciseTicker(dayOfWeek, variantUsed, restAfterSeconds, exerciseTitle)
        }
    }

    fun resetExerciseTimer() {
        exerciseTimerJob?.cancel()
        _exerciseTimer.value = ActiveExerciseTimerState(
            completionSignal = _exerciseTimer.value.completionSignal
        )
    }

    private fun launchExerciseTicker(
        dayOfWeek: Int,
        variantUsed: String,
        restAfterSeconds: Int,
        exerciseTitle: String
    ) {
        exerciseTimerJob?.cancel()
        exerciseTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                val current = _exerciseTimer.value
                if (!current.isRunning || current.phase == ExerciseTimerPhase.IDLE) break
                val next = current.remainingSeconds - 1
                if (next <= 0) {
                    if (current.phase == ExerciseTimerPhase.PREP) {
                        _exerciseTimer.value = current.copy(
                            phase = ExerciseTimerPhase.WORK,
                            remainingSeconds = current.targetWorkSeconds,
                            totalSeconds = current.targetWorkSeconds
                        )
                    } else {
                        // Work timer completed! Auto-log set/cardio in Room.
                        val exId = current.exerciseId
                        val setNum = current.setNumber
                        val workSecs = current.targetWorkSeconds
                        _exerciseTimer.value = current.copy(
                            phase = ExerciseTimerPhase.IDLE,
                            isRunning = false,
                            remainingSeconds = 0,
                            completionSignal = current.completionSignal + 1
                        )
                        repository.logSetCompleted(
                            weekKey = currentWeekKey,
                            dayOfWeek = dayOfWeek,
                            exerciseId = exId,
                            variantUsed = variantUsed,
                            setNumber = setNum,
                            weightLb = 0f,
                            repsCompleted = 1,
                            durationSeconds = workSecs
                        )
                        if (restAfterSeconds > 0) {
                            startRestTimer(restAfterSeconds, exerciseTitle)
                        }
                        break
                    }
                } else {
                    _exerciseTimer.value = current.copy(remainingSeconds = next)
                }
            }
        }
    }

    // --- Nutrition Controls ---

    fun selectMealOption(slot: MealSlot, option: MealOption) {
        val current = mealChecksToday.value[slot.name]
        val isCompleted = current?.completed ?: false
        viewModelScope.launch {
            repository.toggleMealOption(todayIso, slot, option, isCompleted)
        }
    }

    fun toggleMealCompleted(slot: MealSlot, defaultOption: MealOption) {
        val existing = mealChecksToday.value[slot.name]
        val targetOptionId = existing?.optionId ?: defaultOption.id
        val option = com.example.data.model.NutritionCatalog.optionsForSlot(slot)
            .firstOrNull { it.id == targetOptionId } ?: defaultOption
        val nextCompleted = !(existing?.completed ?: false)
        viewModelScope.launch {
            repository.toggleMealOption(todayIso, slot, option, nextCompleted)
        }
    }

    fun updateWaterGlasses(glasses: Int) {
        viewModelScope.launch {
            repository.setWaterGlasses(todayIso, glasses)
        }
    }

    fun dayCompletionRatio(dayOfWeek: Int, logs: List<ExerciseSetLogEntity>): Pair<Int, Int> {
        val dayPlan = RoutineCatalog.getDay(dayOfWeek)
        val totalSets = dayPlan.exercises.sumOf { it.sets }
        val completedSets = logs.filter { it.dayOfWeek == dayOfWeek }
            .distinctBy { "${it.exerciseId}_${it.setNumber}" }
            .size
        return completedSets to totalSets
    }

    fun isWeightsPhaseDone(dayOfWeek: Int, logs: List<ExerciseSetLogEntity>): Boolean {
        val dayPlan = RoutineCatalog.getDay(dayOfWeek)
        val weightExercises = dayPlan.exercises.filter { it.phase == ExercisePhase.WEIGHTS }
        return weightExercises.all { ex ->
            val doneCount = logs.count { it.dayOfWeek == dayOfWeek && it.exerciseId == ex.id }
            doneCount >= ex.sets
        }
    }
}
