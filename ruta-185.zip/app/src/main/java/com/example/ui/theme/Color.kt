package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Athletic High-Contrast Dark Palette
val CharcoalBg = Color(0xFF0F1419)
val SlateSurface = Color(0xFF171E26)
val SlateElevated = Color(0xFF212B36)
val SlateOutline = Color(0xFF2F3C4A)

val EmeraldPrimary = Color(0xFF22C55E)
val EmeraldOnPrimary = Color(0xFF052E16)
val EmeraldContainer = Color(0xFF123524)
val EmeraldOnContainer = Color(0xFF86EFAC)

val AmberSecondary = Color(0xFFF59E0B)
val AmberOnSecondary = Color(0xFF271702)
val AmberContainer = Color(0xFF36250B)
val AmberOnContainer = Color(0xFFFCD34D)

val SkyTertiary = Color(0xFF38BDF8)
val SkyOnTertiary = Color(0xFF082F49)
val SkyContainer = Color(0xFF0F2D40)
val SkyOnContainer = Color(0xFFBAE6FD)

val RoseError = Color(0xFFFB7185)
val RoseOnError = Color(0xFF4C0519)
val RoseContainer = Color(0xFF3B121D)
val RoseOnContainer = Color(0xFFFECDD3)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)

// Light fallback palette (if user explicitly forces light mode at OS level & theme allows)
val LightBg = Color(0xFFF4F7F5)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE7EFEA)
val LightOutline = Color(0xFFC5D1CA)
val LightEmeraldPrimary = Color(0xFF15803D)
val LightAmberSecondary = Color(0xFFB45309)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
