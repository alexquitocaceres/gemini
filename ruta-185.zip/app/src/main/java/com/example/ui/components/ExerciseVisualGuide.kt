package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.data.model.PostureDiagramType

@Composable
fun ExerciseVisualGuide(
    diagramType: PostureDiagramType,
    modifier: Modifier = Modifier
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val accentColor = MaterialTheme.colorScheme.secondary
    val lineColor = MaterialTheme.colorScheme.onSurface
    val mutedColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
    val surfaceBg = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
    val borderColor = MaterialTheme.colorScheme.outline

    val transition = rememberInfiniteTransition(label = "posture_anim")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "movement_phase"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(176.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(surfaceBg)
            .border(1.dp, borderColor, RoundedCornerShape(16.dp))
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            val w = size.width
            val h = size.height

            // Subtle floor reference line
            drawLine(
                color = mutedColor,
                start = Offset(w * 0.08f, h * 0.88f),
                end = Offset(w * 0.92f, h * 0.88f),
                strokeWidth = 3f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
            )

            when (diagramType) {
                PostureDiagramType.PLANK -> drawPlank(w, h, phase, lineColor, primaryColor, accentColor)
                PostureDiagramType.LEG_PRESS -> drawLegPress(w, h, phase, lineColor, primaryColor, mutedColor)
                PostureDiagramType.ROMANIAN_DEADLIFT -> drawRdl(w, h, phase, lineColor, primaryColor, accentColor)
                PostureDiagramType.LEG_EXTENSION -> drawLegExtension(w, h, phase, lineColor, primaryColor, mutedColor)
                PostureDiagramType.LEG_CURL -> drawLegCurl(w, h, phase, lineColor, primaryColor, mutedColor)
                PostureDiagramType.CHEST_PRESS -> drawChestPress(w, h, phase, lineColor, primaryColor, mutedColor)
                PostureDiagramType.SHOULDER_PRESS -> drawShoulderPress(w, h, phase, lineColor, primaryColor, accentColor)
                PostureDiagramType.LATERAL_RAISE -> drawLateralRaise(w, h, phase, lineColor, primaryColor, accentColor)
                PostureDiagramType.LAT_PULLDOWN -> drawLatPulldown(w, h, phase, lineColor, primaryColor, mutedColor)
                PostureDiagramType.SEATED_ROW -> drawSeatedRow(w, h, phase, lineColor, primaryColor, mutedColor)
                PostureDiagramType.FACE_PULL -> drawFacePull(w, h, phase, lineColor, primaryColor, accentColor)
                PostureDiagramType.BICEP_CURL -> drawBicepCurl(w, h, phase, lineColor, primaryColor, accentColor)
                PostureDiagramType.TRICEPS_PUSHDOWN -> drawTricepsPushdown(w, h, phase, lineColor, primaryColor, accentColor)
                PostureDiagramType.LUNGES -> drawLunges(w, h, phase, lineColor, primaryColor, accentColor)
                PostureDiagramType.CALF_RAISE -> drawCalfRaise(w, h, phase, lineColor, primaryColor, accentColor)
                PostureDiagramType.CARDIO_TREADMILL -> drawTreadmill(w, h, phase, lineColor, accentColor, mutedColor)
                PostureDiagramType.CARDIO_BIKE -> drawBike(w, h, phase, lineColor, accentColor, mutedColor)
            }
        }

        Text(
            text = "Guía animada de postura",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(10.dp)
        )
    }
}

private fun DrawScope.drawJoint(center: Offset, color: Color, radius: Float = 8f) {
    drawCircle(color = color, radius = radius, center = center)
}

private fun DrawScope.drawLimb(start: Offset, end: Offset, color: Color, width: Float = 10f) {
    drawLine(color = color, start = start, end = end, strokeWidth = width, cap = StrokeCap.Round)
}

private fun DrawScope.drawHead(center: Offset, color: Color) {
    drawCircle(color = color, radius = 15f, center = center, style = Stroke(width = 6f))
}

private fun DrawScope.drawPlank(
    w: Float, h: Float, phase: Float, body: Color, primary: Color, accent: Color
) {
    val sway = (phase - 0.5f) * 3f
    val ankle = Offset(w * 0.22f, h * 0.85f)
    val hip = Offset(w * 0.48f, h * 0.60f + sway)
    val shoulder = Offset(w * 0.72f, h * 0.52f + sway)
    val head = Offset(w * 0.80f, h * 0.45f + sway)
    val elbow = Offset(w * 0.72f, h * 0.84f)
    val hand = Offset(w * 0.82f, h * 0.84f)

    // Straight alignment reference
    drawLine(
        color = primary.copy(alpha = 0.5f),
        start = ankle,
        end = shoulder,
        strokeWidth = 4f,
        pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f))
    )
    drawLimb(ankle, hip, body)
    drawLimb(hip, shoulder, body)
    drawLimb(shoulder, elbow, body)
    drawLimb(elbow, hand, body)
    drawHead(head, body)
    drawJoint(hip, primary, 10f)
    drawJoint(shoulder, accent, 8f)
}

private fun DrawScope.drawLegPress(
    w: Float, h: Float, phase: Float, body: Color, primary: Color, machine: Color
) {
    val seat = Offset(w * 0.28f, h * 0.74f)
    val backTop = Offset(w * 0.16f, h * 0.44f)
    drawLimb(backTop, seat, machine, 12f)
    drawLimb(seat, Offset(w * 0.40f, h * 0.76f), machine, 12f)

    val kneeX = w * (0.44f + phase * 0.14f)
    val kneeY = h * (0.52f + phase * 0.12f)
    val footX = w * (0.64f + phase * 0.14f)
    val footY = h * 0.42f

    // Sled plate
    drawLimb(Offset(footX + 8f, footY - 22f), Offset(footX + 8f, footY + 34f), primary, 12f)

    drawLimb(Offset(w * 0.22f, h * 0.48f), Offset(w * 0.30f, h * 0.70f), body)
    drawHead(Offset(w * 0.19f, h * 0.35f), body)
    drawLimb(Offset(w * 0.30f, h * 0.70f), Offset(kneeX, kneeY), body)
    drawLimb(Offset(kneeX, kneeY), Offset(footX, footY), primary)
    drawJoint(Offset(kneeX, kneeY), primary, 9f)
}

private fun DrawScope.drawRdl(
    w: Float, h: Float, phase: Float, body: Color, primary: Color, accent: Color
) {
    val foot = Offset(w * 0.45f, h * 0.86f)
    val knee = Offset(w * 0.47f, h * 0.64f)
    val hip = Offset(w * (0.45f - phase * 0.08f), h * 0.46f)
    val shoulder = Offset(w * (0.48f + phase * 0.16f), h * (0.24f + phase * 0.19f))
    val head = Offset(shoulder.x + 14f, shoulder.y - 16f)
    val hand = Offset(shoulder.x + 6f, h * (0.48f + phase * 0.18f))

    drawLimb(foot, knee, body)
    drawLimb(knee, hip, body)
    drawLimb(hip, shoulder, primary)
    drawLimb(shoulder, hand, body)
    drawCircle(color = accent, radius = 11f, center = hand)
    drawHead(head, body)
    drawJoint(hip, accent, 9f)
}

private fun DrawScope.drawLegExtension(
    w: Float, h: Float, phase: Float, body: Color, primary: Color, machine: Color
) {
    val hip = Offset(w * 0.36f, h * 0.62f)
    val knee = Offset(w * 0.52f, h * 0.62f)
    drawLimb(Offset(w * 0.30f, h * 0.35f), hip, machine, 10f)
    drawLimb(hip, knee, machine, 10f)

    val ankleX = w * (0.54f + phase * 0.22f)
    val ankleY = h * (0.84f - phase * 0.22f)
    drawLimb(Offset(w * 0.34f, h * 0.36f), hip, body)
    drawHead(Offset(w * 0.34f, h * 0.24f), body)
    drawLimb(hip, knee, body)
    drawLimb(knee, Offset(ankleX, ankleY), primary)
    drawJoint(Offset(ankleX, ankleY), primary, 9f)
}

private fun DrawScope.drawLegCurl(
    w: Float, h: Float, phase: Float, body: Color, primary: Color, machine: Color
) {
    drawLimb(Offset(w * 0.25f, h * 0.66f), Offset(w * 0.64f, h * 0.66f), machine, 12f)
    val head = Offset(w * 0.22f, h * 0.52f)
    val shoulder = Offset(w * 0.32f, h * 0.58f)
    val hip = Offset(w * 0.48f, h * 0.60f)
    val knee = Offset(w * 0.64f, h * 0.62f)
    val ankle = Offset(w * (0.82f - phase * 0.22f), h * (0.62f - phase * 0.30f))

    drawHead(head, body)
    drawLimb(shoulder, hip, body)
    drawLimb(hip, knee, body)
    drawLimb(knee, ankle, primary)
    drawJoint(ankle, primary, 9f)
}

private fun DrawScope.drawChestPress(
    w: Float, h: Float, phase: Float, body: Color, primary: Color, machine: Color
) {
    drawLimb(Offset(w * 0.34f, h * 0.30f), Offset(w * 0.34f, h * 0.72f), machine, 12f)
    val hip = Offset(w * 0.40f, h * 0.66f)
    val shoulder = Offset(w * 0.38f, h * 0.40f)
    val hand = Offset(w * (0.48f + phase * 0.22f), h * 0.42f)

    drawHead(Offset(w * 0.38f, h * 0.26f), body)
    drawLimb(hip, shoulder, body)
    drawLimb(hip, Offset(w * 0.52f, h * 0.68f), body)
    drawLimb(Offset(w * 0.52f, h * 0.68f), Offset(w * 0.52f, h * 0.86f), body)
    drawLimb(shoulder, hand, primary)
    drawJoint(hand, primary, 10f)
}

private fun DrawScope.drawShoulderPress(
    w: Float, h: Float, phase: Float, body: Color, primary: Color, accent: Color
) {
    val hip = Offset(w * 0.50f, h * 0.72f)
    val shoulder = Offset(w * 0.50f, h * 0.46f)
    val elbowY = h * (0.48f - phase * 0.16f)
    val handY = h * (0.34f - phase * 0.20f)

    drawHead(Offset(w * 0.50f, h * 0.32f), body)
    drawLimb(hip, shoulder, body)
    drawLimb(shoulder, Offset(w * 0.38f, elbowY), body)
    drawLimb(Offset(w * 0.38f, elbowY), Offset(w * 0.40f, handY), primary)
    drawLimb(shoulder, Offset(w * 0.62f, elbowY), body)
    drawLimb(Offset(w * 0.62f, elbowY), Offset(w * 0.60f, handY), primary)
    drawJoint(Offset(w * 0.40f, handY), accent, 9f)
    drawJoint(Offset(w * 0.60f, handY), accent, 9f)
}

private fun DrawScope.drawLateralRaise(
    w: Float, h: Float, phase: Float, body: Color, primary: Color, accent: Color
) {
    val footL = Offset(w * 0.45f, h * 0.86f)
    val footR = Offset(w * 0.55f, h * 0.86f)
    val hip = Offset(w * 0.50f, h * 0.58f)
    val shoulder = Offset(w * 0.50f, h * 0.32f)

    val handSpread = 0.08f + phase * 0.20f
    val handY = h * (0.58f - phase * 0.26f)

    drawHead(Offset(w * 0.50f, h * 0.18f), body)
    drawLimb(footL, hip, body)
    drawLimb(footR, hip, body)
    drawLimb(hip, shoulder, body)
    drawLimb(shoulder, Offset(w * (0.50f - handSpread), handY), primary)
    drawLimb(shoulder, Offset(w * (0.50f + handSpread), handY), primary)
    drawJoint(Offset(w * (0.50f - handSpread), handY), accent, 8f)
    drawJoint(Offset(w * (0.50f + handSpread), handY), accent, 8f)
}

private fun DrawScope.drawLatPulldown(
    w: Float, h: Float, phase: Float, body: Color, primary: Color, machine: Color
) {
    val barY = h * (0.14f + phase * 0.22f)
    drawLine(color = machine, start = Offset(w * 0.50f, 0f), end = Offset(w * 0.50f, barY), strokeWidth = 4f)
    drawLimb(Offset(w * 0.32f, barY), Offset(w * 0.68f, barY), primary, 8f)

    val shoulder = Offset(w * 0.50f, h * 0.46f)
    val hip = Offset(w * 0.50f, h * 0.72f)
    drawHead(Offset(w * 0.50f, h * 0.34f), body)
    drawLimb(hip, shoulder, body)
    drawLimb(shoulder, Offset(w * 0.34f, barY), body)
    drawLimb(shoulder, Offset(w * 0.66f, barY), body)
}

private fun DrawScope.drawSeatedRow(
    w: Float, h: Float, phase: Float, body: Color, primary: Color, machine: Color
) {
    drawLimb(Offset(w * 0.64f, h * 0.76f), Offset(w * 0.74f, h * 0.40f), machine, 8f)
    val hip = Offset(w * 0.34f, h * 0.70f)
    val shoulder = Offset(w * 0.34f, h * 0.42f)
    val handX = w * (0.62f - phase * 0.22f)

    drawHead(Offset(w * 0.34f, h * 0.28f), body)
    drawLimb(hip, shoulder, body)
    drawLimb(hip, Offset(w * 0.64f, h * 0.72f), body)
    drawLimb(shoulder, Offset(handX, h * 0.48f), primary)
    drawJoint(Offset(handX, h * 0.48f), primary, 9f)
}

private fun DrawScope.drawFacePull(
    w: Float, h: Float, phase: Float, body: Color, primary: Color, accent: Color
) {
    val hip = Offset(w * 0.38f, h * 0.58f)
    val shoulder = Offset(w * 0.38f, h * 0.32f)
    val handX = w * (0.64f - phase * 0.20f)
    drawLine(color = accent, start = Offset(w * 0.80f, h * 0.28f), end = Offset(handX, h * 0.28f), strokeWidth = 4f)
    drawHead(Offset(w * 0.38f, h * 0.20f), body)
    drawLimb(Offset(w * 0.36f, h * 0.86f), hip, body)
    drawLimb(hip, shoulder, body)
    drawLimb(shoulder, Offset(handX, h * 0.28f), primary)
    drawJoint(Offset(handX, h * 0.28f), primary, 8f)
}

private fun DrawScope.drawBicepCurl(
    w: Float, h: Float, phase: Float, body: Color, primary: Color, accent: Color
) {
    val hip = Offset(w * 0.46f, h * 0.58f)
    val shoulder = Offset(w * 0.46f, h * 0.32f)
    val elbow = Offset(w * 0.47f, h * 0.48f)
    val handX = w * (0.50f + (1f - phase) * 0.10f)
    val handY = h * (0.64f - phase * 0.28f)

    drawHead(Offset(w * 0.46f, h * 0.18f), body)
    drawLimb(Offset(w * 0.44f, h * 0.86f), hip, body)
    drawLimb(hip, shoulder, body)
    drawLimb(shoulder, elbow, body)
    drawLimb(elbow, Offset(handX, handY), primary)
    drawJoint(Offset(handX, handY), accent, 10f)
}

private fun DrawScope.drawTricepsPushdown(
    w: Float, h: Float, phase: Float, body: Color, primary: Color, accent: Color
) {
    val hip = Offset(w * 0.40f, h * 0.58f)
    val shoulder = Offset(w * 0.42f, h * 0.32f)
    val elbow = Offset(w * 0.45f, h * 0.46f)
    val handX = w * (0.60f - (1f - phase) * 0.04f)
    val handY = h * (0.38f + phase * 0.24f)

    drawLine(color = accent, start = Offset(w * 0.62f, 0f), end = Offset(handX, handY), strokeWidth = 4f)
    drawHead(Offset(w * 0.42f, h * 0.18f), body)
    drawLimb(Offset(w * 0.38f, h * 0.86f), hip, body)
    drawLimb(hip, shoulder, body)
    drawLimb(shoulder, elbow, body)
    drawLimb(elbow, Offset(handX, handY), primary)
    drawJoint(Offset(handX, handY), primary, 9f)
}

private fun DrawScope.drawLunges(
    w: Float, h: Float, phase: Float, body: Color, primary: Color, accent: Color
) {
    val drop = phase * h * 0.14f
    val hip = Offset(w * 0.48f, h * 0.50f + drop)
    val shoulder = Offset(w * 0.48f, h * 0.24f + drop)
    val frontKnee = Offset(w * 0.62f, h * 0.64f + drop * 0.4f)
    val frontFoot = Offset(w * 0.64f, h * 0.86f)
    val backKnee = Offset(w * 0.36f, h * 0.66f + drop * 0.9f)
    val backFoot = Offset(w * 0.28f, h * 0.86f)

    drawHead(Offset(w * 0.48f, h * 0.12f + drop), body)
    drawLimb(hip, shoulder, body)
    drawLimb(hip, frontKnee, primary)
    drawLimb(frontKnee, frontFoot, primary)
    drawLimb(hip, backKnee, body)
    drawLimb(backKnee, backFoot, body)
    drawJoint(frontKnee, accent, 8f)
}

private fun DrawScope.drawCalfRaise(
    w: Float, h: Float, phase: Float, body: Color, primary: Color, accent: Color
) {
    val lift = phase * 18f
    val toe = Offset(w * 0.52f, h * 0.86f)
    val ankle = Offset(w * 0.48f, h * 0.82f - lift)
    val knee = Offset(w * 0.48f, h * 0.60f - lift)
    val hip = Offset(w * 0.48f, h * 0.44f - lift)
    val shoulder = Offset(w * 0.48f, h * 0.22f - lift)

    drawRect(color = accent.copy(alpha = 0.4f), topLeft = Offset(w * 0.44f, h * 0.84f), size = Size(w * 0.14f, 10f))
    drawHead(Offset(w * 0.48f, h * 0.12f - lift), body)
    drawLimb(toe, ankle, primary)
    drawLimb(ankle, knee, primary)
    drawLimb(knee, hip, body)
    drawLimb(hip, shoulder, body)
    drawJoint(ankle, accent, 8f)
}

private fun DrawScope.drawTreadmill(
    w: Float, h: Float, phase: Float, body: Color, accent: Color, machine: Color
) {
    // Inclined belt
    drawLimb(Offset(w * 0.24f, h * 0.82f), Offset(w * 0.74f, h * 0.68f), machine, 12f)
    drawLimb(Offset(w * 0.70f, h * 0.70f), Offset(w * 0.66f, h * 0.28f), machine, 10f)
    val stride = (phase - 0.5f) * w * 0.14f
    val hip = Offset(w * 0.48f, h * 0.48f)
    val shoulder = Offset(w * 0.50f, h * 0.24f)

    drawHead(Offset(w * 0.52f, h * 0.12f), body)
    drawLimb(hip, shoulder, body)
    drawLimb(hip, Offset(w * 0.48f + stride, h * 0.72f), accent)
    drawLimb(hip, Offset(w * 0.48f - stride, h * 0.74f), body)
}

private fun DrawScope.drawBike(
    w: Float, h: Float, phase: Float, body: Color, accent: Color, machine: Color
) {
    drawCircle(color = machine, radius = 26f, center = Offset(w * 0.52f, h * 0.74f), style = Stroke(width = 6f))
    val angle = phase * Math.PI.toFloat() * 2f
    val pedal = Offset(
        w * 0.52f + kotlin.math.cos(angle) * 20f,
        h * 0.74f + kotlin.math.sin(angle) * 20f
    )
    val hip = Offset(w * 0.38f, h * 0.50f)
    val shoulder = Offset(w * 0.46f, h * 0.26f)
    drawLimb(Offset(w * 0.66f, h * 0.76f), Offset(w * 0.62f, h * 0.34f), machine, 8f)
    drawHead(Offset(w * 0.48f, h * 0.14f), body)
    drawLimb(hip, shoulder, body)
    drawLimb(shoulder, Offset(w * 0.62f, h * 0.34f), body)
    drawLimb(hip, pedal, accent)
    drawJoint(pedal, accent, 8f)
}
