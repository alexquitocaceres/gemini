package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.data.local.WeightLogEntity
import kotlin.math.max
import kotlin.math.min

@Composable
fun WeightChart(
    logs: List<WeightLogEntity>,
    targetWeightLb: Float,
    modifier: Modifier = Modifier
) {
    val lineColor = MaterialTheme.colorScheme.primary
    val goalColor = MaterialTheme.colorScheme.secondary
    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
    val surfaceColor = MaterialTheme.colorScheme.surface

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = surfaceColor)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Evolución semanal (lb)",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Meta: ${targetWeightLb.toInt()} lb",
                    style = MaterialTheme.typography.labelLarge,
                    color = goalColor
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (logs.isEmpty()) {
                Text(
                    text = "Registra tu peso semanal para ver tu tendencia hacia las ${targetWeightLb.toInt()} lb.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 28.dp)
                )
            } else {
                val weights = logs.map { it.weightLb }
                val minVal = min(weights.min(), targetWeightLb) - 4f
                val maxVal = max(weights.max(), targetWeightLb) + 4f
                val range = (maxVal - minVal).coerceAtLeast(10f)

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                        .padding(vertical = 8.dp)
                ) {
                    val w = size.width
                    val h = size.height
                    val leftPad = 14f
                    val rightPad = 14f
                    val usableW = w - leftPad - rightPad

                    fun yFor(weight: Float): Float {
                        val norm = (weight - minVal) / range
                        return h - (norm * h)
                    }

                    // Horizontal subtle grid lines
                    listOf(0.25f, 0.5f, 0.75f).forEach { frac ->
                        drawLine(
                            color = gridColor,
                            start = Offset(leftPad, h * frac),
                            end = Offset(w - rightPad, h * frac),
                            strokeWidth = 2f
                        )
                    }

                    // Goal dashed line (185 lb)
                    val goalY = yFor(targetWeightLb)
                    drawLine(
                        color = goalColor,
                        start = Offset(leftPad, goalY),
                        end = Offset(w - rightPad, goalY),
                        strokeWidth = 4f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))
                    )

                    val points = if (logs.size == 1) {
                        listOf(
                            Offset(leftPad, yFor(logs.first().weightLb)),
                            Offset(w - rightPad, yFor(logs.first().weightLb))
                        )
                    } else {
                        logs.mapIndexed { index, entry ->
                            val x = leftPad + (index.toFloat() / (logs.size - 1)) * usableW
                            Offset(x, yFor(entry.weightLb))
                        }
                    }

                    val fillPath = Path().apply {
                        moveTo(points.first().x, h)
                        points.forEach { pt -> lineTo(pt.x, pt.y) }
                        lineTo(points.last().x, h)
                        close()
                    }
                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                lineColor.copy(alpha = 0.28f),
                                lineColor.copy(alpha = 0.02f)
                            )
                        )
                    )

                    val strokePath = Path().apply {
                        moveTo(points.first().x, points.first().y)
                        for (i in 1 until points.size) {
                            lineTo(points[i].x, points[i].y)
                        }
                    }
                    drawPath(
                        path = strokePath,
                        color = lineColor,
                        style = Stroke(width = 6f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )

                    val dotPoints = if (logs.size == 1) listOf(points.first()) else points
                    dotPoints.forEach { pt ->
                        drawCircle(color = surfaceColor, radius = 10f, center = pt)
                        drawCircle(color = lineColor, radius = 7f, center = pt)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Inicio: ${logs.first().weightLb.toInt()} lb",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Actual: ${String.format("%.1f", logs.last().weightLb)} lb",
                        style = MaterialTheme.typography.labelSmall,
                        color = lineColor
                    )
                }
            }
        }
    }
}
