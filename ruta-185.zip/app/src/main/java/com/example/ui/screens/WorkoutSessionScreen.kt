package com.example.ui.screens

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DirectionsRun
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.ExercisePreferenceEntity
import com.example.data.local.ExerciseSessionSummaryEntity
import com.example.data.local.ExerciseSetLogEntity
import com.example.data.model.ExerciseDefinition
import com.example.data.model.ExercisePhase
import com.example.data.model.ExerciseTrackingMode
import com.example.data.model.RoutineCatalog
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.viewmodel.ActiveExerciseTimerState
import com.example.ui.viewmodel.ExerciseTimerPhase
import com.example.ui.viewmodel.RestTimerState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkoutSessionScreen(
    dayOfWeek: Int,
    setLogs: List<ExerciseSetLogEntity>,
    summaries: List<ExerciseSessionSummaryEntity>,
    preferences: Map<String, ExercisePreferenceEntity>,
    progressionAlerts: Map<String, Boolean>,
    restTimer: RestTimerState,
    exerciseTimer: ActiveExerciseTimerState,
    onBack: () -> Unit,
    onSelectVariant: (String, String) -> Unit,
    onSaveMachineNote: (String, String) -> Unit,
    onToggleSetLog: (
        exercise: ExerciseDefinition,
        variant: String,
        setNumber: Int,
        weightLb: Float,
        reps: Int,
        durationSeconds: Int,
        currentlyDone: Boolean
    ) -> Unit,
    onSaveEffort: (
        exercise: ExerciseDefinition,
        variant: String,
        allSetsDone: Boolean,
        effortRating: Int,
        avgWeightLb: Float
    ) -> Unit,
    onStartTimedExercise: (
        exercise: ExerciseDefinition,
        variant: String,
        setNumber: Int,
        workSeconds: Int,
        includePrep: Boolean
    ) -> Unit,
    onToggleExerciseTimerPause: (ExerciseDefinition, String) -> Unit,
    onResetExerciseTimer: () -> Unit,
    onToggleRestPause: () -> Unit,
    onAdjustRest: (Int) -> Unit,
    onStopRest: () -> Unit,
    onOpenExerciseGuide: (ExerciseDefinition) -> Unit
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current
    val dayPlan = remember(dayOfWeek) { RoutineCatalog.getDay(dayOfWeek) }
    val weightExercises = remember(dayPlan) {
        dayPlan.exercises.filter { it.phase == ExercisePhase.WEIGHTS }
    }
    val cardioExercises = remember(dayPlan) {
        dayPlan.exercises.filter { it.phase == ExercisePhase.CARDIO }
    }

    val allWeightsCompleted = remember(weightExercises, setLogs) {
        weightExercises.all { ex ->
            setLogs.count { it.exerciseId == ex.id } >= ex.sets
        }
    }

    // Vibrate softly when rest timer or timed exercise finishes
    LaunchedEffect(restTimer.completionSignal, exerciseTimer.completionSignal) {
        if (restTimer.completionSignal > 0 || exerciseTimer.completionSignal > 0) {
            triggerShortVibration(context)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "${dayPlan.dayName} · ${dayPlan.focusTitle}",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "Pesas primero · Cardio después",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("session_back_button")
                    ) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver a rutina")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            AnimatedVisibility(visible = restTimer.isActive) {
                RestTimerBar(
                    restTimer = restTimer,
                    onTogglePause = onToggleRestPause,
                    onAdjust = onAdjustRest,
                    onSkip = onStopRest
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Phase 1 Header
            item {
                PhaseHeader(
                    title = "FASE 1 · PESAS",
                    subtitle = "Deja 1–2 repeticiones en reserva en tu última serie",
                    isWeights = true
                )
            }

            items(weightExercises, key = { it.id }) { exercise ->
                val pref = preferences[exercise.id]
                val selectedVariant = pref?.selectedVariant?.ifBlank { null }
                    ?: exercise.variants.first()
                val exerciseLogs = setLogs.filter { it.exerciseId == exercise.id }
                val summary = summaries.firstOrNull { it.exerciseId == exercise.id }
                val suggestIncrease = progressionAlerts[exercise.id] == true

                if (exercise.trackingMode == ExerciseTrackingMode.TIMED_SETS) {
                    PlankExerciseCard(
                        exercise = exercise,
                        selectedVariant = selectedVariant,
                        logs = exerciseLogs,
                        summary = summary,
                        timerState = exerciseTimer,
                        onStartTimer = { setNum, secs ->
                            onStartTimedExercise(exercise, selectedVariant, setNum, secs, true)
                        },
                        onTogglePause = { onToggleExerciseTimerPause(exercise, selectedVariant) },
                        onResetTimer = onResetExerciseTimer,
                        onToggleSetManual = { setNum, secs, done ->
                            onToggleSetLog(exercise, selectedVariant, setNum, 0f, 1, secs, done)
                        },
                        onSaveEffort = { rating ->
                            onSaveEffort(
                                exercise,
                                selectedVariant,
                                exerciseLogs.size >= exercise.sets,
                                rating,
                                0f
                            )
                        },
                        onOpenGuide = { onOpenExerciseGuide(exercise) }
                    )
                } else {
                    WeightExerciseCard(
                        exercise = exercise,
                        selectedVariant = selectedVariant,
                        savedLastWeight = pref?.lastWeightLb ?: exercise.beginnerStartWeightLb,
                        savedNote = pref?.machineSettingNote ?: "",
                        suggestIncrease = suggestIncrease,
                        logs = exerciseLogs,
                        summary = summary,
                        onSelectVariant = { onSelectVariant(exercise.id, it) },
                        onSaveNote = { onSaveMachineNote(exercise.id, it) },
                        onToggleSet = { setNum, weightLb, reps, currentlyDone ->
                            onToggleSetLog(exercise, selectedVariant, setNum, weightLb, reps, 0, currentlyDone)
                        },
                        onSaveEffort = { rating, avgWeight ->
                            onSaveEffort(
                                exercise,
                                selectedVariant,
                                exerciseLogs.size >= exercise.sets,
                                rating,
                                avgWeight
                            )
                        },
                        onOpenGuide = { onOpenExerciseGuide(exercise) }
                    )
                }
            }

            // Phase 2 Header (Cardio)
            item {
                Spacer(modifier = Modifier.height(6.dp))
                PhaseHeader(
                    title = "FASE 2 · CARDIO",
                    subtitle = if (allWeightsCompleted) {
                        "¡Pesas listas! Hora de tu cardio quema grasa"
                    } else {
                        "Realiza este bloque al terminar tus ejercicios de pesas"
                    },
                    isWeights = false
                )
            }

            items(cardioExercises, key = { it.id }) { cardio ->
                val pref = preferences[cardio.id]
                val selectedVariant = pref?.selectedVariant?.ifBlank { null }
                    ?: cardio.variants.first()
                val cardioLogs = setLogs.filter { it.exerciseId == cardio.id }
                CardioExerciseCard(
                    exercise = cardio,
                    selectedVariant = selectedVariant,
                    savedNote = pref?.machineSettingNote ?: "",
                    isCompleted = cardioLogs.isNotEmpty(),
                    timerState = exerciseTimer,
                    onSelectVariant = { onSelectVariant(cardio.id, it) },
                    onSaveNote = { onSaveMachineNote(cardio.id, it) },
                    onStartCardioTimer = { secs ->
                        onStartTimedExercise(cardio, selectedVariant, 1, secs, false)
                    },
                    onTogglePause = { onToggleExerciseTimerPause(cardio, selectedVariant) },
                    onResetTimer = onResetExerciseTimer,
                    onToggleCardioDone = { secs, done ->
                        onToggleSetLog(cardio, selectedVariant, 1, 0f, 1, secs, done)
                    },
                    onOpenGuide = { onOpenExerciseGuide(cardio) }
                )
            }

            item { Spacer(modifier = Modifier.height(48.dp)) }
        }
    }
}

@Composable
private fun PhaseHeader(title: String, subtitle: String, isWeights: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    if (isWeights) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.secondaryContainer
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isWeights) Icons.Rounded.FitnessCenter else Icons.Rounded.DirectionsRun,
                contentDescription = null,
                tint = if (isWeights) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = if (isWeights) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun WeightExerciseCard(
    exercise: ExerciseDefinition,
    selectedVariant: String,
    savedLastWeight: Float,
    savedNote: String,
    suggestIncrease: Boolean,
    logs: List<ExerciseSetLogEntity>,
    summary: ExerciseSessionSummaryEntity?,
    onSelectVariant: (String) -> Unit,
    onSaveNote: (String) -> Unit,
    onToggleSet: (Int, Float, Int, Boolean) -> Unit,
    onSaveEffort: (Int, Float) -> Unit,
    onOpenGuide: () -> Unit
) {
    var weightInput by remember(exercise.id, savedLastWeight) {
        mutableFloatStateOf(if (savedLastWeight > 0f) savedLastWeight else exercise.beginnerStartWeightLb)
    }
    var showNoteField by remember { mutableStateOf(false) }
    var noteInput by remember(savedNote) { mutableStateOf(savedNote) }

    val completedCount = logs.size
    val allDone = completedCount >= exercise.sets

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = if (allDone) 1.5.dp else 1.dp,
            color = if (allDone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = selectedVariant,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${exercise.targetDisplay} · Descanso ${exercise.restSeconds}s",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(
                    onClick = onOpenGuide,
                    modifier = Modifier.testTag("video_btn_${exercise.id}")
                ) {
                    Icon(Icons.Rounded.PlayCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Video / Guía")
                }
            }

            if (suggestIncrease) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.TrendingUp,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Completaste todas las series fácil 2 semanas seguidas: ¡sube +5 lb hoy!",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            if (exercise.variants.size > 1) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    exercise.variants.forEach { variant ->
                        FilterChip(
                            selected = variant == selectedVariant,
                            onClick = { onSelectVariant(variant) },
                            label = { Text(variant, style = MaterialTheme.typography.labelSmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                    }
                }
            }

            // Quick global weight stepper for the exercise
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Peso base (lb)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${formatWeight(weightInput)} lb",
                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        onClick = { weightInput = (weightInput - 5f).coerceAtLeast(0f) },
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(Icons.Rounded.Remove, contentDescription = "Restar 5 libras")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedButton(
                        onClick = { weightInput += 5f },
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = "Sumar 5 libras")
                    }
                }
            }

            // Set-by-set interactive rows
            for (setNum in 1..exercise.sets) {
                val existingLog = logs.firstOrNull { it.setNumber == setNum }
                val isDone = existingLog != null
                var setWeight by remember(exercise.id, setNum, existingLog?.weightLb, weightInput) {
                    mutableFloatStateOf(existingLog?.weightLb ?: weightInput)
                }
                var setReps by remember(exercise.id, setNum, existingLog?.repsCompleted) {
                    mutableIntStateOf(existingLog?.repsCompleted ?: exercise.targetRepsMax)
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isDone) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                            else MaterialTheme.colorScheme.background
                        )
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "S$setNum",
                        style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = if (isDone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${formatWeight(setWeight)} lb",
                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        IconButton(
                            onClick = { if (!isDone) setReps = (setReps - 1).coerceAtLeast(1) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Rounded.Remove, contentDescription = "Menos reps", modifier = Modifier.size(16.dp))
                        }
                        Text(
                            text = "$setReps reps",
                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        IconButton(
                            onClick = { if (!isDone) setReps += 1 },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = "Más reps", modifier = Modifier.size(16.dp))
                        }
                    }

                    Button(
                        onClick = { onToggleSet(setNum, setWeight, setReps, isDone) },
                        modifier = Modifier
                            .height(40.dp)
                            .testTag("set_btn_${exercise.id}_$setNum"),
                        contentPadding = PaddingValues(horizontal = 12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isDone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (isDone) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    ) {
                        Icon(
                            imageVector = if (isDone) Icons.Rounded.CheckCircle else Icons.Rounded.Check,
                            contentDescription = if (isDone) "Serie completada" else "Marcar serie",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isDone) "Hecho" else "Listo", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            // Effort Rating (RIR) for 2-week rule
            if (completedCount > 0) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "¿Cómo sentiste las series hoy? (regla de progreso)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val avgW = logs.map { it.weightLb }.average().toFloat()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        EffortChip(
                            label = "Fácil (3+)",
                            selected = summary?.effortRating == 1,
                            onClick = { onSaveEffort(1, avgW) },
                            modifier = Modifier.weight(1f)
                        )
                        EffortChip(
                            label = "Ideal (1-2)",
                            selected = summary?.effortRating == 2,
                            onClick = { onSaveEffort(2, avgW) },
                            modifier = Modifier.weight(1f)
                        )
                        EffortChip(
                            label = "Al límite (0)",
                            selected = summary?.effortRating == 3,
                            onClick = { onSaveEffort(3, avgW) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Machine adjustment note toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (savedNote.isNotBlank()) "Ajuste: $savedNote" else "Ajuste de máquina / asiento",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                TextButton(onClick = { showNoteField = !showNoteField }) {
                    Text(if (showNoteField) "Cerrar" else "Editar nota")
                }
            }

            if (showNoteField) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = noteInput,
                        onValueChange = { noteInput = it },
                        label = { Text("Ej. Asiento en 4") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(onClick = {
                        onSaveNote(noteInput)
                        showNoteField = false
                    }) {
                        Text("Guardar")
                    }
                }
            }
        }
    }
}

@Composable
private fun PlankExerciseCard(
    exercise: ExerciseDefinition,
    selectedVariant: String,
    logs: List<ExerciseSetLogEntity>,
    summary: ExerciseSessionSummaryEntity?,
    timerState: ActiveExerciseTimerState,
    onStartTimer: (Int, Int) -> Unit,
    onTogglePause: () -> Unit,
    onResetTimer: () -> Unit,
    onToggleSetManual: (Int, Int, Boolean) -> Unit,
    onSaveEffort: (Int) -> Unit,
    onOpenGuide: () -> Unit
) {
    var selectedSeconds by remember { mutableIntStateOf(35) }
    val nextSet = (logs.size + 1).coerceAtMost(exercise.sets)
    val isThisTimerActive = timerState.exerciseId == exercise.id && timerState.phase != ExerciseTimerPhase.IDLE
    val allDone = logs.size >= exercise.sets

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = if (allDone) 1.5.dp else 1.dp,
            color = if (allDone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = selectedVariant,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${exercise.targetDisplay} · Descanso ${exercise.restSeconds}s",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
                TextButton(onClick = onOpenGuide) {
                    Icon(Icons.Rounded.PlayCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Video / Guía")
                }
            }

            // Duration selector (30, 35, 40s)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30, 35, 40).forEach { sec ->
                    FilterChip(
                        selected = selectedSeconds == sec,
                        onClick = { selectedSeconds = sec },
                        label = { Text("${sec} seg") }
                    )
                }
            }

            // Active Plank Countdown Panel
            Surface(
                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.65f),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val statusLabel = when {
                        isThisTimerActive && timerState.phase == ExerciseTimerPhase.PREP ->
                            "¡Prepárate en posición! (Serie ${timerState.setNumber})"
                        isThisTimerActive && timerState.phase == ExerciseTimerPhase.WORK ->
                            "Mantén el abdomen firme (Serie ${timerState.setNumber})"
                        allDone -> "¡Todas las series de plancha completadas!"
                        else -> "Listo para Serie $nextSet de ${exercise.sets}"
                    }
                    Text(
                        text = statusLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    Text(
                        text = if (isThisTimerActive) formatSeconds(timerState.remainingSeconds)
                        else formatSeconds(selectedSeconds),
                        style = MaterialTheme.typography.displaySmall.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (!isThisTimerActive) {
                            Button(
                                onClick = { onStartTimer(nextSet, selectedSeconds) },
                                modifier = Modifier.testTag("start_plank_timer_btn"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.secondary,
                                    contentColor = MaterialTheme.colorScheme.onSecondary
                                )
                            ) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Iniciar Serie $nextSet")
                            }
                        } else {
                            Button(onClick = onTogglePause) {
                                Icon(
                                    imageVector = if (timerState.isRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    contentDescription = null
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (timerState.isRunning) "Pausar" else "Reanudar")
                            }
                            OutlinedButton(onClick = onResetTimer) {
                                Icon(Icons.Rounded.Replay, contentDescription = "Reiniciar cronómetro")
                            }
                        }
                    }
                }
            }

            // Set pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (setNum in 1..exercise.sets) {
                    val done = logs.any { it.setNumber == setNum }
                    FilterChip(
                        selected = done,
                        onClick = { onToggleSetManual(setNum, selectedSeconds, done) },
                        label = { Text("Serie $setNum") },
                        leadingIcon = {
                            if (done) {
                                Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            if (logs.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    EffortChip("Fácil", summary?.effortRating == 1, { onSaveEffort(1) }, Modifier.weight(1f))
                    EffortChip("Ideal", summary?.effortRating == 2, { onSaveEffort(2) }, Modifier.weight(1f))
                    EffortChip("Al límite", summary?.effortRating == 3, { onSaveEffort(3) }, Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun CardioExerciseCard(
    exercise: ExerciseDefinition,
    selectedVariant: String,
    savedNote: String,
    isCompleted: Boolean,
    timerState: ActiveExerciseTimerState,
    onSelectVariant: (String) -> Unit,
    onSaveNote: (String) -> Unit,
    onStartCardioTimer: (Int) -> Unit,
    onTogglePause: () -> Unit,
    onResetTimer: () -> Unit,
    onToggleCardioDone: (Int, Boolean) -> Unit,
    onOpenGuide: () -> Unit
) {
    val minMins = (exercise.targetDurationMinSeconds / 60).coerceAtLeast(15)
    val maxMins = (exercise.targetDurationMaxSeconds / 60).coerceAtLeast(minMins)
    val minuteChoices = remember(minMins, maxMins) {
        if (minMins == maxMins) listOf(minMins)
        else listOf(minMins, (minMins + maxMins) / 2, maxMins).distinct()
    }
    var selectedMinutes by remember(exercise.id) { mutableIntStateOf(minuteChoices.first()) }
    var noteInput by remember(savedNote) { mutableStateOf(savedNote) }
    val isThisTimerActive = timerState.exerciseId == exercise.id && timerState.phase != ExerciseTimerPhase.IDLE

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = if (isCompleted) 1.5.dp else 1.dp,
            color = if (isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary.copy(alpha = 0.6f)
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = selectedVariant,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = exercise.targetDisplay,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
                TextButton(onClick = onOpenGuide) {
                    Icon(Icons.Rounded.PlayCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Guía")
                }
            }

            if (exercise.variants.size > 1) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    exercise.variants.forEach { variant ->
                        FilterChip(
                            selected = variant == selectedVariant,
                            onClick = { onSelectVariant(variant) },
                            label = { Text(variant, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }

            if (minuteChoices.size > 1) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    minuteChoices.forEach { mins ->
                        FilterChip(
                            selected = selectedMinutes == mins,
                            onClick = { selectedMinutes = mins },
                            label = { Text("$mins min") }
                        )
                    }
                }
            }

            Surface(
                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = if (isCompleted) "Cardio completado" else "Cronómetro de cardio",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    Text(
                        text = if (isThisTimerActive) formatSeconds(timerState.remainingSeconds)
                        else formatSeconds(selectedMinutes * 60),
                        style = MaterialTheme.typography.displaySmall.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (!isThisTimerActive) {
                            Button(
                                onClick = { onStartCardioTimer(selectedMinutes * 60) },
                                modifier = Modifier.testTag("start_cardio_timer_btn"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.secondary,
                                    contentColor = MaterialTheme.colorScheme.onSecondary
                                )
                            ) {
                                Icon(Icons.Rounded.Timer, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Iniciar ${selectedMinutes}m")
                            }
                        } else {
                            Button(onClick = onTogglePause) {
                                Icon(
                                    imageVector = if (timerState.isRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    contentDescription = null
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (timerState.isRunning) "Pausar" else "Seguir")
                            }
                            OutlinedButton(onClick = onResetTimer) {
                                Icon(Icons.Rounded.Replay, contentDescription = "Reiniciar")
                            }
                        }

                        OutlinedButton(
                            onClick = { onToggleCardioDone(selectedMinutes * 60, isCompleted) },
                            modifier = Modifier.testTag("complete_cardio_btn")
                        ) {
                            Icon(
                                imageVector = if (isCompleted) Icons.Rounded.CheckCircle else Icons.Rounded.Check,
                                contentDescription = null,
                                tint = if (isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isCompleted) "Completado" else "Marcar listo")
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = noteInput,
                    onValueChange = { noteInput = it },
                    label = { Text("Inclinación / velocidad / nivel (opcional)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { onSaveNote(noteInput) }) {
                    Text("Guardar")
                }
            }
        }
    }
}

@Composable
private fun RestTimerBar(
    restTimer: RestTimerState,
    onTogglePause: () -> Unit,
    onAdjust: (Int) -> Unit,
    onSkip: () -> Unit
) {
    val progress = if (restTimer.totalSeconds > 0) {
        restTimer.remainingSeconds.toFloat() / restTimer.totalSeconds.toFloat()
    } else 0f

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = 8.dp,
        shadowElevation = 8.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(4.dp),
                color = MaterialTheme.colorScheme.secondary
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Descanso · ${restTimer.exerciseName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                    Text(
                        text = formatSeconds(restTimer.remainingSeconds),
                        style = MaterialTheme.typography.headlineSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = MaterialTheme.colorScheme.secondary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { onAdjust(-15) }) { Text("-15s") }
                    TextButton(onClick = { onAdjust(15) }) { Text("+15s") }
                    IconButton(onClick = onTogglePause) {
                        Icon(
                            imageVector = if (restTimer.isPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                            contentDescription = "Pausar descanso"
                        )
                    }
                    TextButton(onClick = onSkip) { Text("Saltar") }
                }
            }
        }
    }
}

@Composable
private fun EffortChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
        modifier = modifier,
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
        )
    )
}

private fun formatSeconds(totalSeconds: Int): String {
    val safe = totalSeconds.coerceAtLeast(0)
    val mins = safe / 60
    val secs = safe % 60
    return String.format("%02d:%02d", mins, secs)
}

private fun formatWeight(weight: Float): String {
    return if (weight % 1f == 0f) weight.toInt().toString()
    else String.format("%.1f", weight)
}

private fun triggerShortVibration(context: Context) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator?.vibrate(
                VibrationEffect.createOneShot(240L, VibrationEffect.DEFAULT_AMPLITUDE)
            )
        } else {
            @Suppress("DEPRECATION")
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(
                    VibrationEffect.createOneShot(240L, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(240L)
            }
        }
    } catch (_: Exception) {
        // Ignore if device has no vibrator
    }
}
