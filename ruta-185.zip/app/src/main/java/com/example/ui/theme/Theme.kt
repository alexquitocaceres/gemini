package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val RutaDarkColorScheme = darkColorScheme(
    primary = EmeraldPrimary,
    onPrimary = EmeraldOnPrimary,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = EmeraldOnContainer,
    secondary = AmberSecondary,
    onSecondary = AmberOnSecondary,
    secondaryContainer = AmberContainer,
    onSecondaryContainer = AmberOnContainer,
    tertiary = SkyTertiary,
    onTertiary = SkyOnTertiary,
    tertiaryContainer = SkyContainer,
    onTertiaryContainer = SkyOnContainer,
    error = RoseError,
    onError = RoseOnError,
    errorContainer = RoseContainer,
    onErrorContainer = RoseOnContainer,
    background = CharcoalBg,
    onBackground = TextPrimary,
    surface = SlateSurface,
    onSurface = TextPrimary,
    surfaceVariant = SlateElevated,
    onSurfaceVariant = TextSecondary,
    outline = SlateOutline,
    outlineVariant = SlateOutline
)

private val RutaLightColorScheme = lightColorScheme(
    primary = LightEmeraldPrimary,
    onPrimary = LightSurface,
    primaryContainer = EmeraldOnContainer,
    onPrimaryContainer = EmeraldOnPrimary,
    secondary = LightAmberSecondary,
    onSecondary = LightSurface,
    secondaryContainer = AmberOnContainer,
    onSecondaryContainer = AmberOnSecondary,
    tertiary = SkyTertiary,
    onTertiary = SkyOnTertiary,
    background = LightBg,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightTextSecondary,
    outline = LightOutline,
    outlineVariant = LightOutline
)

val RutaShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun Ruta185Theme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) RutaDarkColorScheme else RutaLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = RutaTypography,
        shapes = RutaShapes,
        content = content
    )
}
