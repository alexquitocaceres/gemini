package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.model.ExerciseDefinition
import com.example.ui.components.ExerciseVideoModal
import com.example.ui.screens.LogWeightDialog
import com.example.ui.screens.NutritionScreen
import com.example.ui.screens.ProgressScreen
import com.example.ui.screens.RoutineHomeScreen
import com.example.ui.screens.WorkoutSessionScreen
import com.example.ui.theme.Ruta185Theme
import com.example.ui.viewmodel.RutaViewModel

const val ROUTE_ROUTINE = "routine"
const val ROUTE_PROGRESS = "progress"
const val ROUTE_NUTRITION = "nutrition"
const val ROUTE_SESSION = "session"

data class BottomTabItem(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Ruta185Theme {
                Ruta185App()
            }
        }
    }
}

@Composable
fun Ruta185App(viewModel: RutaViewModel = viewModel()) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val userGoal by viewModel.userGoal.collectAsStateWithLifecycle()
    val selectedDay by viewModel.selectedDayOfWeek.collectAsStateWithLifecycle()
    val weightLogs by viewModel.weightLogs.collectAsStateWithLifecycle()
    val preferences by viewModel.exercisePreferences.collectAsStateWithLifecycle()
    val weekSetLogs by viewModel.weekSetLogs.collectAsStateWithLifecycle()
    val activeDayLogs by viewModel.activeDaySetLogs.collectAsStateWithLifecycle()
    val activeDaySummaries by viewModel.activeDaySummaries.collectAsStateWithLifecycle()
    val progressionAlerts by viewModel.progressionAlerts.collectAsStateWithLifecycle()
    val restTimer by viewModel.restTimer.collectAsStateWithLifecycle()
    val exerciseTimer by viewModel.exerciseTimer.collectAsStateWithLifecycle()
    val mealChecks by viewModel.mealChecksToday.collectAsStateWithLifecycle()
    val waterGlasses by viewModel.waterGlassesToday.collectAsStateWithLifecycle()

    var activeGuideExercise by remember { mutableStateOf<ExerciseDefinition?>(null) }
    var showWeightDialog by remember { mutableStateOf(false) }

    val tabs = remember {
        listOf(
            BottomTabItem(ROUTE_ROUTINE, "Rutina", Icons.Rounded.FitnessCenter, "nav_tab_routine"),
            BottomTabItem(ROUTE_PROGRESS, "Progreso", Icons.Rounded.ShowChart, "nav_tab_progress"),
            BottomTabItem(ROUTE_NUTRITION, "Comida", Icons.Rounded.Restaurant, "nav_tab_nutrition")
        )
    }

    val isTopLevelDestination = currentRoute in setOf(ROUTE_ROUTINE, ROUTE_PROGRESS, ROUTE_NUTRITION)

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (isTopLevelDestination && !useNavRail) {
                    NavigationBar(
                        windowInsets = WindowInsets.navigationBars,
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        tabs.forEach { tab ->
                            NavigationBarItem(
                                selected = currentRoute == tab.route,
                                onClick = {
                                    navController.navigate(tab.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isTopLevelDestination && useNavRail) {
                    NavigationRail(containerColor = MaterialTheme.colorScheme.surface) {
                        tabs.forEach { tab ->
                            NavigationRailItem(
                                selected = currentRoute == tab.route,
                                onClick = {
                                    navController.navigate(tab.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = ROUTE_ROUTINE,
                    modifier = Modifier
                        .weight(1f)
                        .widthIn(max = 760.dp)
                        .align(Alignment.CenterVertically)
                ) {
                    composable(ROUTE_ROUTINE) {
                        RoutineHomeScreen(
                            userGoal = userGoal,
                            selectedDayOfWeek = selectedDay,
                            weekSetLogs = weekSetLogs,
                            preferences = preferences,
                            progressionAlerts = progressionAlerts,
                            onSelectDay = viewModel::selectDay,
                            onStartWorkout = { day ->
                                viewModel.selectDay(day)
                                navController.navigate("$ROUTE_SESSION/$day")
                            },
                            onOpenExerciseGuide = { activeGuideExercise = it },
                            onOpenQuickWeightLog = { showWeightDialog = true }
                        )
                    }

                    composable(ROUTE_PROGRESS) {
                        ProgressScreen(
                            userGoal = userGoal,
                            weightLogs = weightLogs,
                            onOpenLogWeightDialog = { showWeightDialog = true },
                            onDeleteWeightLog = viewModel::deleteWeightLog
                        )
                    }

                    composable(ROUTE_NUTRITION) {
                        NutritionScreen(
                            userGoal = userGoal,
                            mealChecks = mealChecks,
                            waterGlasses = waterGlasses,
                            onSelectMealOption = viewModel::selectMealOption,
                            onToggleMealCompleted = viewModel::toggleMealCompleted,
                            onUpdateWater = viewModel::updateWaterGlasses,
                            onUpdateNutritionTargets = { cals, prot ->
                                viewModel.updateGoalTargets(userGoal.targetWeightLb, cals, prot)
                            }
                        )
                    }

                    composable(
                        route = "$ROUTE_SESSION/{dayOfWeek}",
                        arguments = listOf(navArgument("dayOfWeek") { type = NavType.IntType })
                    ) { entry ->
                        val dayArg = entry.arguments?.getInt("dayOfWeek") ?: selectedDay
                        WorkoutSessionScreen(
                            dayOfWeek = dayArg,
                            setLogs = activeDayLogs,
                            summaries = activeDaySummaries,
                            preferences = preferences,
                            progressionAlerts = progressionAlerts,
                            restTimer = restTimer,
                            exerciseTimer = exerciseTimer,
                            onBack = { navController.popBackStack() },
                            onSelectVariant = viewModel::selectVariant,
                            onSaveMachineNote = viewModel::saveMachineNote,
                            onToggleSetLog = { ex, variant, setNum, weightLb, reps, secs, currentlyDone ->
                                viewModel.toggleSetLog(
                                    dayOfWeek = dayArg,
                                    exerciseId = ex.id,
                                    variantUsed = variant,
                                    setNumber = setNum,
                                    weightLb = weightLb,
                                    repsCompleted = reps,
                                    durationSeconds = secs,
                                    restSeconds = ex.restSeconds,
                                    exerciseTitle = variant,
                                    currentlyCompleted = currentlyDone
                                )
                            },
                            onSaveEffort = { ex, variant, allDone, rating, avgW ->
                                viewModel.saveEffortRating(
                                    dayOfWeek = dayArg,
                                    exerciseId = ex.id,
                                    variantUsed = variant,
                                    allSetsCompleted = allDone,
                                    effortRating = rating,
                                    avgWeightLb = avgW
                                )
                            },
                            onStartTimedExercise = { ex, variant, setNum, secs, prep ->
                                viewModel.startTimedExercise(
                                    exerciseId = ex.id,
                                    setNumber = setNum,
                                    workSeconds = secs,
                                    includePrepCountdown = prep,
                                    dayOfWeek = dayArg,
                                    variantUsed = variant,
                                    restAfterSeconds = ex.restSeconds,
                                    exerciseTitle = variant
                                )
                            },
                            onToggleExerciseTimerPause = { ex, variant ->
                                viewModel.toggleExerciseTimerPause(
                                    dayOfWeek = dayArg,
                                    variantUsed = variant,
                                    restAfterSeconds = ex.restSeconds,
                                    exerciseTitle = variant
                                )
                            },
                            onResetExerciseTimer = viewModel::resetExerciseTimer,
                            onToggleRestPause = viewModel::toggleRestPause,
                            onAdjustRest = viewModel::adjustRestTimer,
                            onStopRest = viewModel::stopRestTimer,
                            onOpenExerciseGuide = { activeGuideExercise = it }
                        )
                    }
                }
            }
        }
    }

    activeGuideExercise?.let { exercise ->
        val pref = preferences[exercise.id]
        ExerciseVideoModal(
            exercise = exercise,
            selectedVariant = pref?.selectedVariant?.ifBlank { null } ?: exercise.variants.first(),
            savedCustomUrl = pref?.customVideoUrl ?: "",
            onSaveCustomUrl = { url -> viewModel.saveCustomVideoUrl(exercise.id, url) },
            onDismiss = { activeGuideExercise = null }
        )
    }

    if (showWeightDialog) {
        LogWeightDialog(
            currentWeightLb = userGoal.currentWeightLb,
            onDismiss = { showWeightDialog = false },
            onSave = viewModel::logWeeklyWeight
        )
    }
}
